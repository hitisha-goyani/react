

import { Col, Container, Row } from 'react-bootstrap'
const Contact = () => {
  return (
    <Container>
        <Row className='row-cols-4 justify-content-center'>
            <Col>
             <h1>Contact</h1>
            </Col>
         
        </Row>
    </Container>
  )
}

export default Contact
