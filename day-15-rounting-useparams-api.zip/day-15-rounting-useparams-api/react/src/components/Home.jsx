

import { Col, Container, Row } from 'react-bootstrap'

const Home = () => {
  return (
    <Container>
        <Row className='row-cols-4 justify-content-center my-5'>
            <Col>
             <h1>Home</h1>
            </Col>
         
        </Row>
    </Container>
  )
}

export default Home